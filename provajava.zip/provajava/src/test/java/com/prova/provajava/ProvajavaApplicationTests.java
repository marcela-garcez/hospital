package com.prova.provajava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProvajavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
